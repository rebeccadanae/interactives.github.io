Brookings Interactive
---

Yohann Paris - yparis@brookings.edu
Last update: March 22nd, 2017

#Tools
CodeKit (codekitapp.com) is used to process and compile the files... but anyother tools can be used.

# Format
The project is broken down into multiple simple file:
- index.html
- app.js
- app.css
